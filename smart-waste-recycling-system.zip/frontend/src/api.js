const BASE = import.meta.env.VITE_API_URL || "http://localhost:3000";

export const STATUSES = ["Pending", "Scheduled", "Collected", "Recycled", "Cancelled"];

// Mirrors the backend's validStatusTransitions
export const TRANSITIONS = {
  Pending: ["Scheduled", "Cancelled"],
  Scheduled: ["Collected", "Cancelled"],
  Collected: ["Recycled"],
  Recycled: [],
  Cancelled: []
};

export class ApiError extends Error {
  constructor(problem, status) {
    super(problem?.detail || problem?.title || `Request failed (${status})`);
    this.status = status;
    this.problem = problem;
    this.fieldErrors = problem?.errors || [];
  }
}

async function request(path, { method = "GET", body, headers = {} } = {}) {
  let res;
  try {
    res = await fetch(`${BASE}${path}`, {
      method,
      headers: {
        Accept: "application/json",
        ...(body ? { "Content-Type": "application/json" } : {}),
        ...headers
      },
      body: body ? JSON.stringify(body) : undefined
    });
  } catch {
    throw new ApiError({ detail: `Cannot reach the API at ${BASE}. Is the backend running?` }, 0);
  }

  if (res.status === 204) return { data: null, res };

  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) throw new ApiError(data, res.status);
  return { data, res };
}

export const getCategories = async () => (await request("/api/waste-categories")).data;

export const getPickups = async ({ status, userId } = {}) => {
  const params = new URLSearchParams();
  if (status) params.set("status", status);
  if (userId) params.set("userId", userId);
  const qs = params.toString();
  return (await request(`/api/pickups${qs ? `?${qs}` : ""}`)).data;
};

export const createPickup = async (payload) =>
  (await request("/api/pickups", {
    method: "POST",
    body: payload,
    headers: { "Idempotency-Key": crypto.randomUUID() }
  })).data;

// Fetch the latest ETag first so concurrent edits are caught (If-Match -> 412)
async function currentEtag(id) {
  const { res } = await request(`/api/pickups/${id}`);
  return res.headers.get("ETag");
}

export async function updatePickup(id, changes) {
  const etag = await currentEtag(id);
  return (await request(`/api/pickups/${id}`, {
    method: "PATCH",
    body: changes,
    headers: etag ? { "If-Match": etag } : {}
  })).data;
}

export async function deletePickup(id) {
  const etag = await currentEtag(id);
  await request(`/api/pickups/${id}`, {
    method: "DELETE",
    headers: etag ? { "If-Match": etag } : {}
  });
}
