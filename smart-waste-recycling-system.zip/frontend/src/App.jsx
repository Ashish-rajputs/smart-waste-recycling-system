import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ApiError, STATUSES, TRANSITIONS,
  getCategories, getPickups, createPickup, updatePickup, deletePickup
} from "./api.js";

const ICONS = {
  Plastic: "🧴", Paper: "📄", Metal: "🔩", Glass: "🍾",
  "Electronic Waste": "🔌", "Organic Waste": "🍃"
};

function Toast({ toast, onClose }) {
  if (!toast) return null;
  return (
    <div className={`toast ${toast.type}`} role="status" onClick={onClose}>
      {toast.message}
    </div>
  );
}

function Stats({ pickups }) {
  const totalKg = pickups.reduce((s, p) => s + p.quantityKg, 0);
  const recycledKg = pickups
    .filter((p) => p.status === "Recycled")
    .reduce((s, p) => s + p.quantityKg, 0);
  const open = pickups.filter((p) => ["Pending", "Scheduled"].includes(p.status)).length;
  const cards = [
    ["Total requests", pickups.length],
    ["Open requests", open],
    ["Total waste (kg)", totalKg.toFixed(1)],
    ["Recycled (kg)", recycledKg.toFixed(1)]
  ];
  return (
    <section className="stats">
      {cards.map(([label, value]) => (
        <div className="stat" key={label}>
          <span className="stat-value">{value}</span>
          <span className="stat-label">{label}</span>
        </div>
      ))}
    </section>
  );
}

function PickupForm({ categories, onCreated, notify }) {
  const [form, setForm] = useState({ wasteCategoryId: "", quantityKg: "", address: "", userId: "" });
  const [errors, setErrors] = useState({});
  const [busy, setBusy] = useState(false);

  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setErrors({});
    try {
      const payload = {
        wasteCategoryId: Number(form.wasteCategoryId),
        quantityKg: Number(form.quantityKg),
        address: form.address
      };
      if (form.userId) payload.userId = Number(form.userId);
      const created = await createPickup(payload);
      setForm({ wasteCategoryId: "", quantityKg: "", address: "", userId: form.userId });
      notify("success", `Pickup #${created.id} requested.`);
      onCreated();
    } catch (err) {
      if (err instanceof ApiError && err.fieldErrors.length) {
        setErrors(Object.fromEntries(err.fieldErrors.map((x) => [x.field, x.message])));
      }
      notify("error", err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form className="card" onSubmit={submit} noValidate>
      <h2>Request a pickup</h2>

      <label>
        Waste category
        <select value={form.wasteCategoryId} onChange={set("wasteCategoryId")} required>
          <option value="">Select a category…</option>
          {categories.map((c) => (
            <option key={c.id} value={c.id}>{ICONS[c.name] || "♻️"} {c.name}</option>
          ))}
        </select>
        {errors.wasteCategoryId && <small className="err">{errors.wasteCategoryId}</small>}
      </label>

      <label>
        Quantity (kg)
        <input type="number" step="0.1" min="0.1" max="10000" value={form.quantityKg}
          onChange={set("quantityKg")} placeholder="e.g. 4.5" required />
        {errors.quantityKg && <small className="err">{errors.quantityKg}</small>}
      </label>

      <label>
        Pickup address
        <textarea rows="3" value={form.address} onChange={set("address")}
          placeholder="Hostel Block A, Demo Campus" required />
        {errors.address && <small className="err">{errors.address}</small>}
      </label>

      <label>
        User ID <span className="muted">(optional)</span>
        <input type="number" min="1" value={form.userId} onChange={set("userId")} />
        {errors.userId && <small className="err">{errors.userId}</small>}
      </label>

      <button className="btn primary" disabled={busy}>
        {busy ? "Submitting…" : "Submit request"}
      </button>
    </form>
  );
}

function EditRow({ pickup, onSave, onCancel }) {
  const [address, setAddress] = useState(pickup.address);
  const [quantityKg, setQuantityKg] = useState(pickup.quantityKg);
  return (
    <div className="edit">
      <input type="number" step="0.1" min="0.1" value={quantityKg}
        onChange={(e) => setQuantityKg(e.target.value)} aria-label="Quantity in kg" />
      <input value={address} onChange={(e) => setAddress(e.target.value)} aria-label="Address" />
      <button className="btn small primary"
        onClick={() => onSave({ address, quantityKg: Number(quantityKg) })}>Save</button>
      <button className="btn small" onClick={onCancel}>Cancel</button>
    </div>
  );
}

function PickupItem({ pickup, onChange, onDelete, onEdit }) {
  const [editing, setEditing] = useState(false);
  const next = TRANSITIONS[pickup.status];
  const canEdit = !["Recycled", "Cancelled"].includes(pickup.status);
  const canDelete = ["Pending", "Cancelled"].includes(pickup.status);

  return (
    <li className="pickup">
      <div className="pickup-head">
        <strong>
          #{pickup.id} · {ICONS[pickup.wasteCategory] || "♻️"} {pickup.wasteCategory}
        </strong>
        <span className={`badge ${pickup.status}`}>{pickup.status}</span>
      </div>

      {editing ? (
        <EditRow pickup={pickup} onCancel={() => setEditing(false)}
          onSave={async (c) => { if (await onEdit(pickup.id, c)) setEditing(false); }} />
      ) : (
        <p className="meta">
          {pickup.quantityKg} kg · {pickup.address}
          <br />
          <span className="muted">
            {new Date(pickup.createdAt).toLocaleString()}
            {pickup.userId ? ` · user ${pickup.userId}` : ""}
          </span>
        </p>
      )}

      <div className="actions">
        {next.map((s) => (
          <button key={s} className={`btn small ${s === "Cancelled" ? "danger-outline" : "primary"}`}
            onClick={() => onChange(pickup.id, s)}>
            {s === "Cancelled" ? "Cancel pickup" : `Mark ${s}`}
          </button>
        ))}
        {canEdit && !editing && (
          <button className="btn small" onClick={() => setEditing(true)}>Edit</button>
        )}
        {canDelete && (
          <button className="btn small danger" onClick={() => onDelete(pickup.id)}>Delete</button>
        )}
      </div>
    </li>
  );
}

export default function App() {
  const [categories, setCategories] = useState([]);
  const [pickups, setPickups] = useState([]);
  const [filter, setFilter] = useState("");
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState(null);

  const notify = useCallback((type, message) => {
    setToast({ type, message });
    setTimeout(() => setToast(null), 4500);
  }, []);

  const load = useCallback(async () => {
    try {
      setPickups(await getPickups());
    } catch (err) {
      notify("error", err.message);
    } finally {
      setLoading(false);
    }
  }, [notify]);

  useEffect(() => {
    getCategories().then(setCategories).catch((e) => notify("error", e.message));
    load();
  }, [load, notify]);

  const visible = useMemo(
    () => (filter ? pickups.filter((p) => p.status === filter) : pickups),
    [pickups, filter]
  );

  async function run(action, okMessage) {
    try {
      await action();
      notify("success", okMessage);
      await load();
      return true;
    } catch (err) {
      notify("error", err.message);
      if (err.status === 412) await load();
      return false;
    }
  }

  const changeStatus = (id, status) =>
    run(() => updatePickup(id, { status }), `Pickup #${id} is now ${status}.`);
  const edit = (id, changes) => run(() => updatePickup(id, changes), `Pickup #${id} updated.`);
  const remove = (id) => {
    if (!window.confirm(`Delete pickup #${id}?`)) return;
    return run(() => deletePickup(id), `Pickup #${id} deleted.`);
  };

  return (
    <>
      <header className="hero">
        <h1>♻️ Smart Waste Recycling Portal</h1>
        <p>Request pickups, track recycling progress, and keep waste out of landfills.</p>
      </header>

      <main>
        <Stats pickups={pickups} />

        <div className="layout">
          <PickupForm categories={categories} onCreated={load} notify={notify} />

          <section className="card">
            <div className="list-head">
              <h2>Pickup requests</h2>
              <select value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="Filter by status">
                <option value="">All statuses</option>
                {STATUSES.map((s) => <option key={s}>{s}</option>)}
              </select>
            </div>

            {loading ? (
              <p className="muted">Loading…</p>
            ) : visible.length === 0 ? (
              <p className="muted">No pickup requests found.</p>
            ) : (
              <ul className="pickups">
                {visible.map((p) => (
                  <PickupItem key={p.id} pickup={p}
                    onChange={changeStatus} onEdit={edit} onDelete={remove} />
                ))}
              </ul>
            )}
          </section>
        </div>
      </main>

      <Toast toast={toast} onClose={() => setToast(null)} />
    </>
  );
}
