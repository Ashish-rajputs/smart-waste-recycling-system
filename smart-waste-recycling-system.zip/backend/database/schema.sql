CREATE DATABASE IF NOT EXISTS smart_waste_recycling
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE smart_waste_recycling;

CREATE TABLE IF NOT EXISTS waste_categories (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(80) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uq_waste_categories_name (name)
);

CREATE TABLE IF NOT EXISTS pickups (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NULL,
  waste_category_id INT UNSIGNED NOT NULL,
  quantity_kg DECIMAL(10,2) NOT NULL,
  address VARCHAR(500) NOT NULL,
  status ENUM('Pending','Scheduled','Collected','Recycled','Cancelled')
    NOT NULL DEFAULT 'Pending',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_pickups_user_id (user_id),
  KEY idx_pickups_status (status),
  KEY idx_pickups_created_at (created_at),
  CONSTRAINT fk_pickups_waste_category
    FOREIGN KEY (waste_category_id) REFERENCES waste_categories(id)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT chk_pickups_quantity CHECK (quantity_kg > 0)
);

INSERT IGNORE INTO waste_categories (name)
VALUES ('Plastic'), ('Paper'), ('Metal'), ('Glass'), ('Electronic Waste'), ('Organic Waste');
