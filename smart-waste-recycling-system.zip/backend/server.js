require("dotenv").config();

const app = require("./src/app");
const { testConnection } = require("./config/database");

async function startServer() {
  const port = Number(process.env.PORT || 3000);

  try {
    await testConnection();
    app.listen(port, () => {
      console.log(`Smart Waste Recycling Portal API running at http://localhost:${port}`);
    });
  } catch (error) {
    console.error("Database connection failed:", error.message);
    process.exitCode = 1;
  }
}

if (require.main === module) {
  startServer();
}

module.exports = { startServer };
