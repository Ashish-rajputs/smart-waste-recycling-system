const test = require("node:test");
const assert = require("node:assert/strict");
const {
  isPositiveInteger,
  isPickupStatus,
  validatePickupPayload,
  validatePickupUpdate,
  validStatusTransitions
} = require("../src/utils/validation");
const { createRequestFingerprint } = require("../src/utils/idempotency");

test("positive integer validation rejects zero and non-numeric input", () => {
  assert.equal(isPositiveInteger("12"), true);
  assert.equal(isPositiveInteger("0"), false);
  assert.equal(isPositiveInteger("abc"), false);
});

test("pickup status validation only accepts configured statuses", () => {
  assert.equal(isPickupStatus("Pending"), true);
  assert.equal(isPickupStatus("Unknown"), false);
});

test("valid create payload returns no errors", () => {
  assert.deepEqual(validatePickupPayload({
    wasteCategoryId: 1,
    quantityKg: 2.5,
    address: "House 12, Main Road"
  }), []);
});

test("invalid create payload reports relevant fields", () => {
  const errors = validatePickupPayload({
    wasteCategoryId: 0,
    quantityKg: -2,
    address: "x"
  });
  assert.ok(errors.some((error) => error.field === "wasteCategoryId"));
  assert.ok(errors.some((error) => error.field === "quantityKg"));
  assert.ok(errors.some((error) => error.field === "address"));
});

test("update requires at least one allowed field", () => {
  assert.equal(validatePickupUpdate({}).length, 1);
  assert.deepEqual(validatePickupUpdate({ status: "Scheduled" }), []);
});

test("terminal pickup statuses have no outgoing transitions", () => {
  assert.deepEqual(validStatusTransitions.Recycled, []);
  assert.deepEqual(validStatusTransitions.Cancelled, []);
});

test("request fingerprint is deterministic for the same body", () => {
  const body = { wasteCategoryId: 1, quantityKg: 2, address: "Example Street" };
  assert.equal(createRequestFingerprint(body), createRequestFingerprint(body));
});
