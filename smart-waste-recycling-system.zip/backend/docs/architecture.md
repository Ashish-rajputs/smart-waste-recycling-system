# System Architecture

```text
Client / Web Frontend
        |
        | HTTP requests (JSON or XML)
        v
Express Application (src/app.js)
        |
        +-- Security headers, CORS, rate limiting
        +-- Category routes
        +-- Pickup routes
        +-- Validation and Problem Details errors
        +-- JSON/XML content negotiation
        |
        v
MySQL Connection Pool (config/database.js)
        |
        +-- waste_categories
        +-- pickups
```

SOAP artifacts under `docs/soap-integration/` document a proposed external recycling partner. They are design artifacts, not a live integration.
