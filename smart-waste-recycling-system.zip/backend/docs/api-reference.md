# API Reference

Base URL: `http://localhost:3000`

| Method | Path | Description |
|---|---|---|
| GET | `/` | Service metadata |
| GET | `/health` | Health check |
| GET | `/api/waste-categories` | List waste categories |
| POST | `/api/pickups` | Create a pickup |
| GET | `/api/pickups` | List pickups; optional `userId`, `status` |
| GET | `/api/pickups/:id` | Read one pickup |
| PATCH | `/api/pickups/:id` | Update status, address, or quantity |
| DELETE | `/api/pickups/:id` | Delete Pending/Cancelled pickup |

## Create pickup body
```json
{
  "wasteCategoryId": 1,
  "quantityKg": 4.5,
  "address": "Hostel Block A, Demo Campus"
}
```

`userId` is optional and nullable in this academic baseline. A successful POST returns `201 Created` and `Location`.
