# Database Design

## waste_categories
Stores supported material types such as Plastic, Paper, Metal, Glass, Electronic Waste, and Organic Waste.

## pickups
Stores a pickup request, its category, quantity, address, lifecycle status, and creation timestamp.

### Design notes
- `waste_category_id` references `waste_categories.id`.
- `user_id` is nullable because this baseline does not include authentication or a users table yet.
- `quantity_kg` must be positive.
- The allowed status values are Pending, Scheduled, Collected, Recycled, and Cancelled.
- SQL is executed with parameterized statements.
