# SOAP Partner Integration — Assignment 3

This directory contains illustrative XML and WSDL examples for a proposed recycling partner service. The endpoint uses the reserved `.invalid` domain and will not connect to a real partner.

The example operation is `submitPickupRequest`, with pickup reference, category, quantity, and address. A real integration requires a provider-issued WSDL, endpoint, authentication method, and error contract.

Fault mapping proposed for the portal:
- `invalidPickup` -> HTTP 422 / `validation-error`
- `partnerUnavailable` -> HTTP 503 / `partner-unavailable`
- `pickupRejected` -> HTTP 409 / `pickup-rejected`
