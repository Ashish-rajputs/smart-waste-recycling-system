# Assignment 5 — HTTP Methods and Headers

| Method | Safe | Idempotent | Portal use |
|---|---|---|---|
| GET | Yes | Yes | Read categories/pickups |
| POST | No | No by default | Create pickup |
| PATCH | No | Not guaranteed | Update pickup |
| DELETE | No | Semantically intended to be | Delete eligible pickup |

Headers demonstrated:
- `Content-Type` and `Accept` for representation format
- `Location` after creation
- `Idempotency-Key` for safe retries of pickup creation
- `ETag` and `If-None-Match` for conditional reads
- `If-Match` to guard against stale changes
- `Retry-After` for rate limiting
- CORS and security headers from middleware

Authentication and authorization are not implemented in this academic baseline and must be added before public deployment.
