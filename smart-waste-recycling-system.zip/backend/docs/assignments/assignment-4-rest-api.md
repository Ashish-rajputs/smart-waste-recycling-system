# Assignment 4 — REST API Design

## Resources
- `waste-categories`: supported recyclable material types.
- `pickups`: collection requests submitted by portal users.

## Resource operations
| Method | Path | Purpose |
|---|---|---|
| GET | `/api/waste-categories` | List categories |
| POST | `/api/pickups` | Create a pickup |
| GET | `/api/pickups` | List and filter pickups |
| GET | `/api/pickups/{id}` | Retrieve a pickup |
| PATCH | `/api/pickups/{id}` | Update an allowed field |
| DELETE | `/api/pickups/{id}` | Delete a Pending or Cancelled pickup |

The OpenAPI contract is at `docs/openapi.yaml`. Creation returns 201 and Location. Invalid fields return 422 Problem Details. Idempotency-Key supports same-process replay of identical create requests.
