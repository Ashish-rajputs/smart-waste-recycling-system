# Assignment 3 — SOAP Integration Design

**Project:** Smart Waste Recycling Portal  
**Team leader:** Ashish Kumar Singh  
**Roll number:** 20252651014

The portal may integrate with an external recycling partner using SOAP to submit a pickup request. The repository includes an illustrative WSDL and XML request, response, and fault samples under `docs/soap-integration/`.

The endpoint is intentionally a reserved example domain. It is not a real partner endpoint. In a production integration, the portal team would obtain the provider's WSDL, endpoint URL, authentication instructions, and fault definitions.

SOAP faults should be translated into portal-level Problem Details:
- Invalid pickup -> 422
- Partner unavailable -> 503
- Partner rejection -> 409
