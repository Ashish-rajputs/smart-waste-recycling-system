# Assignment 6 — Validation, Error Handling and Content Negotiation

Errors use the Problem Details shape: `type`, `title`, `status`, `detail`, and optional `errors`.

| Situation | Status |
|---|---:|
| Invalid JSON | 400 |
| Invalid query or ID | 400 |
| Resource not found | 404 |
| Validation error | 422 |
| Idempotency key conflict | 409 |
| Illegal status transition | 409 |
| Failed If-Match condition | 412 |
| Unsupported Accept header | 406 |
| Rate limit exceeded | 429 |
| Unexpected server failure | 500 |

Responses support JSON by default and XML when requested through `Accept: application/xml`. Retry POST only with the same idempotency key and same request body. Wait for Retry-After after a 429.
