function sendProblem(res, status, slug, title, detail, extra = {}) {
  return res.status(status).type("application/problem+json").json({
    type: `https://smart-waste.example/problems/${slug}`,
    title,
    status,
    detail,
    ...extra
  });
}

module.exports = { sendProblem };
