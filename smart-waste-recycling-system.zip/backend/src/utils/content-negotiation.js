const { Builder } = require("xml2js");

function negotiateResponse(req) {
  const accept = (req.get("Accept") || "application/json").toLowerCase();
  if (accept.includes("*/*") || accept.includes("application/json")) return "json";
  if (accept.includes("application/xml") || accept.includes("text/xml")) return "xml";
  return null;
}

function toXml(data) {
  const builder = new Builder({ rootName: "response", headless: false });
  return builder.buildObject({ data });
}

module.exports = { negotiateResponse, toXml };
