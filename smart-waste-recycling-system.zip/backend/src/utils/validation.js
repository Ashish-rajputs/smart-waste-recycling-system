const PICKUP_STATUSES = ["Pending", "Scheduled", "Collected", "Recycled", "Cancelled"];

const validStatusTransitions = {
  Pending: ["Scheduled", "Cancelled"],
  Scheduled: ["Collected", "Cancelled"],
  Collected: ["Recycled"],
  Recycled: [],
  Cancelled: []
};

function isPositiveInteger(value) {
  return /^\d+$/.test(String(value)) && Number(value) > 0;
}

function isPickupStatus(value) {
  return PICKUP_STATUSES.includes(value);
}

function validatePickupPayload(body) {
  if (!body || typeof body !== "object" || Array.isArray(body)) {
    return [{ field: "body", message: "The request body must be a JSON object." }];
  }

  const errors = [];
  if (body.userId !== undefined && body.userId !== null &&
      (!Number.isInteger(body.userId) || body.userId < 1)) {
    errors.push({ field: "userId", message: "userId must be a positive integer or null." });
  }
  if (!Number.isInteger(body.wasteCategoryId) || body.wasteCategoryId < 1) {
    errors.push({ field: "wasteCategoryId", message: "wasteCategoryId must be a positive integer." });
  }
  if (typeof body.quantityKg !== "number" || !Number.isFinite(body.quantityKg) ||
      body.quantityKg <= 0 || body.quantityKg > 10000) {
    errors.push({ field: "quantityKg", message: "quantityKg must be greater than 0 and no more than 10000." });
  }
  if (typeof body.address !== "string" ||
      body.address.trim().length < 5 || body.address.trim().length > 500) {
    errors.push({ field: "address", message: "address must contain 5 to 500 characters." });
  }
  return errors;
}

function validatePickupUpdate(body) {
  if (!body || typeof body !== "object" || Array.isArray(body) || !Object.keys(body).length) {
    return [{ field: "body", message: "Provide at least one field to update." }];
  }

  const errors = [];
  const allowedFields = ["status", "address", "quantityKg"];
  for (const field of Object.keys(body)) {
    if (!allowedFields.includes(field)) {
      errors.push({ field, message: "This field cannot be updated." });
    }
  }
  if (body.status !== undefined && !isPickupStatus(body.status)) {
    errors.push({ field: "status", message: `status must be one of ${PICKUP_STATUSES.join(", ")}.` });
  }
  if (body.address !== undefined &&
      (typeof body.address !== "string" || body.address.trim().length < 5 || body.address.trim().length > 500)) {
    errors.push({ field: "address", message: "address must contain 5 to 500 characters." });
  }
  if (body.quantityKg !== undefined &&
      (typeof body.quantityKg !== "number" || !Number.isFinite(body.quantityKg) ||
       body.quantityKg <= 0 || body.quantityKg > 10000)) {
    errors.push({ field: "quantityKg", message: "quantityKg must be greater than 0 and no more than 10000." });
  }
  return errors;
}

module.exports = {
  PICKUP_STATUSES,
  validStatusTransitions,
  isPositiveInteger,
  isPickupStatus,
  validatePickupPayload,
  validatePickupUpdate
};
