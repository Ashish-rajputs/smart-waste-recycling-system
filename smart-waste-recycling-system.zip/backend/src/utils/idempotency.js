const crypto = require("node:crypto");

// Coursework demonstration only: the Map is cleared when the server restarts.
// Use MySQL or Redis for persistent, multi-instance idempotency in production.
const idempotencyStore = new Map();

function createRequestFingerprint(body) {
  return crypto.createHash("sha256").update(JSON.stringify(body)).digest("hex");
}

module.exports = { idempotencyStore, createRequestFingerprint };
