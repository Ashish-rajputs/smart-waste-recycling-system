const express = require("express");
const { pool } = require("../../config/database");
const { sendProblem } = require("../utils/problem-details");
const { negotiateResponse, toXml } = require("../utils/content-negotiation");
const { createRequestFingerprint, idempotencyStore } = require("../utils/idempotency");
const {
  validatePickupPayload,
  validatePickupUpdate,
  isPositiveInteger,
  isPickupStatus,
  validStatusTransitions
} = require("../utils/validation");

const router = express.Router();

function mapPickup(row) {
  return {
    id: Number(row.id),
    userId: row.user_id == null ? null : Number(row.user_id),
    wasteCategoryId: Number(row.waste_category_id),
    wasteCategory: row.category_name,
    quantityKg: Number(row.quantity_kg),
    address: row.address,
    status: row.status,
    createdAt: row.created_at
  };
}

function responseFormat(req, res) {
  const format = negotiateResponse(req);
  if (!format) {
    sendProblem(res, 406, "not-acceptable", "Not Acceptable",
      "Use Accept: application/json or Accept: application/xml.");
    return null;
  }
  return format;
}

function sendResource(req, res, data, status = 200) {
  const format = responseFormat(req, res);
  if (!format) return;
  if (format === "xml") return res.status(status).type("application/xml").send(toXml(data));
  return res.status(status).json(data);
}

async function findPickupById(id) {
  const [rows] = await pool.execute(
    `SELECT p.id, p.user_id, p.waste_category_id, c.name AS category_name,
            p.quantity_kg, p.address, p.status, p.created_at
     FROM pickups p
     JOIN waste_categories c ON c.id = p.waste_category_id
     WHERE p.id = ?`,
    [id]
  );
  return rows.length ? mapPickup(rows[0]) : null;
}

function makeEtag(pickup) {
  return `"pickup-${pickup.id}-${pickup.status}-${pickup.quantityKg}-${Buffer.from(pickup.address).toString("base64url")}"`;
}

router.post("/", async (req, res, next) => {
  try {
    const errors = validatePickupPayload(req.body);
    if (errors.length) {
      return sendProblem(res, 422, "validation-error", "Validation failed",
        "Correct the fields listed in the errors array.", { errors });
    }

    const key = req.get("Idempotency-Key");
    const requestFingerprint = createRequestFingerprint(req.body);

    if (key !== undefined) {
      if (!key.trim() || key.length > 128) {
        return sendProblem(res, 400, "invalid-idempotency-key", "Invalid Idempotency-Key",
          "Provide a non-empty key no longer than 128 characters.");
      }
      const previous = idempotencyStore.get(key);
      if (previous) {
        if (previous.fingerprint !== requestFingerprint) {
          return sendProblem(res, 409, "idempotency-conflict", "Idempotency conflict",
            "This key was already used with a different request body. Use a new key.");
        }
        res.setHeader("Idempotency-Replayed", "true");
        res.setHeader("Location", previous.location);
        return sendResource(req, res, previous.body, previous.status);
      }
    }

    const [categories] = await pool.execute(
      "SELECT id FROM waste_categories WHERE id = ?",
      [req.body.wasteCategoryId]
    );
    if (!categories.length) {
      return sendProblem(res, 422, "validation-error", "Validation failed",
        "Choose a valid waste category.", {
          errors: [{ field: "wasteCategoryId", message: "The selected category does not exist." }]
        });
    }

    const [result] = await pool.execute(
      "INSERT INTO pickups (user_id, waste_category_id, quantity_kg, address) VALUES (?, ?, ?, ?)",
      [req.body.userId ?? null, req.body.wasteCategoryId, req.body.quantityKg, req.body.address.trim()]
    );

    const pickup = await findPickupById(result.insertId);
    const location = `/api/pickups/${pickup.id}`;
    res.setHeader("Location", location);

    if (key) {
      idempotencyStore.set(key, {
        fingerprint: requestFingerprint,
        location,
        status: 201,
        body: pickup
      });
    }

    return sendResource(req, res, pickup, 201);
  } catch (error) {
    next(error);
  }
});

router.get("/", async (req, res, next) => {
  try {
    const conditions = [];
    const values = [];

    if (req.query.userId !== undefined) {
      if (!isPositiveInteger(req.query.userId)) {
        return sendProblem(res, 400, "invalid-query", "Invalid query parameter",
          "userId must be a positive integer.");
      }
      conditions.push("p.user_id = ?");
      values.push(Number(req.query.userId));
    }

    if (req.query.status !== undefined) {
      if (!isPickupStatus(req.query.status)) {
        return sendProblem(res, 400, "invalid-query", "Invalid query parameter",
          "status must be Pending, Scheduled, Collected, Recycled, or Cancelled.");
      }
      conditions.push("p.status = ?");
      values.push(req.query.status);
    }

    const whereClause = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const [rows] = await pool.execute(
      `SELECT p.id, p.user_id, p.waste_category_id, c.name AS category_name,
              p.quantity_kg, p.address, p.status, p.created_at
       FROM pickups p JOIN waste_categories c ON c.id = p.waste_category_id
       ${whereClause} ORDER BY p.created_at DESC`,
      values
    );
    return sendResource(req, res, rows.map(mapPickup));
  } catch (error) {
    next(error);
  }
});

router.get("/:id", async (req, res, next) => {
  try {
    if (!isPositiveInteger(req.params.id)) {
      return sendProblem(res, 400, "invalid-pickup-id", "Invalid pickup ID",
        "Pickup ID must be a positive integer.");
    }
    const pickup = await findPickupById(Number(req.params.id));
    if (!pickup) {
      return sendProblem(res, 404, "pickup-not-found", "Pickup not found",
        `No pickup exists with ID ${req.params.id}.`);
    }

    const etag = makeEtag(pickup);
    res.setHeader("ETag", etag);
    if (req.get("If-None-Match") === etag) return res.status(304).end();
    return sendResource(req, res, pickup);
  } catch (error) {
    next(error);
  }
});

router.patch("/:id", async (req, res, next) => {
  try {
    if (!isPositiveInteger(req.params.id)) {
      return sendProblem(res, 400, "invalid-pickup-id", "Invalid pickup ID",
        "Pickup ID must be a positive integer.");
    }
    const errors = validatePickupUpdate(req.body);
    if (errors.length) {
      return sendProblem(res, 422, "validation-error", "Validation failed",
        "Correct the fields listed in the errors array.", { errors });
    }

    const current = await findPickupById(Number(req.params.id));
    if (!current) {
      return sendProblem(res, 404, "pickup-not-found", "Pickup not found",
        `No pickup exists with ID ${req.params.id}.`);
    }

    const currentEtag = makeEtag(current);
    const ifMatch = req.get("If-Match");
    if (ifMatch && ifMatch !== currentEtag) {
      return sendProblem(res, 412, "precondition-failed", "Precondition failed",
        "The pickup changed since it was read. Fetch the latest ETag and retry.");
    }

    if (req.body.status !== undefined) {
      if (!validStatusTransitions[current.status]?.includes(req.body.status)) {
        return sendProblem(res, 409, "illegal-status-transition", "Illegal status transition",
          `A pickup cannot transition from ${current.status} to ${req.body.status}.`);
      }
      await pool.execute("UPDATE pickups SET status = ? WHERE id = ?", [req.body.status, current.id]);
    }
    if (req.body.address !== undefined) {
      await pool.execute("UPDATE pickups SET address = ? WHERE id = ?", [req.body.address.trim(), current.id]);
    }
    if (req.body.quantityKg !== undefined) {
      await pool.execute("UPDATE pickups SET quantity_kg = ? WHERE id = ?", [req.body.quantityKg, current.id]);
    }

    const updated = await findPickupById(current.id);
    res.setHeader("ETag", makeEtag(updated));
    return sendResource(req, res, updated);
  } catch (error) {
    next(error);
  }
});

router.delete("/:id", async (req, res, next) => {
  try {
    if (!isPositiveInteger(req.params.id)) {
      return sendProblem(res, 400, "invalid-pickup-id", "Invalid pickup ID",
        "Pickup ID must be a positive integer.");
    }
    const pickup = await findPickupById(Number(req.params.id));
    if (!pickup) {
      return sendProblem(res, 404, "pickup-not-found", "Pickup not found",
        `No pickup exists with ID ${req.params.id}.`);
    }
    if (!["Pending", "Cancelled"].includes(pickup.status)) {
      return sendProblem(res, 409, "pickup-cannot-be-deleted", "Pickup cannot be deleted",
        "Only Pending or Cancelled pickups can be deleted.");
    }

    const ifMatch = req.get("If-Match");
    if (ifMatch && ifMatch !== makeEtag(pickup)) {
      return sendProblem(res, 412, "precondition-failed", "Precondition failed",
        "The pickup changed since it was read. Fetch the latest ETag and retry.");
    }

    await pool.execute("DELETE FROM pickups WHERE id = ?", [pickup.id]);
    return res.status(204).end();
  } catch (error) {
    next(error);
  }
});

module.exports = router;
