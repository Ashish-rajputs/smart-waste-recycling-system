const express = require("express");
const categoryRoutes = require("./waste-category-routes");
const pickupRoutes = require("./pickup-routes");

const router = express.Router();

router.use("/waste-categories", categoryRoutes);
router.use("/pickups", pickupRoutes);

module.exports = router;
