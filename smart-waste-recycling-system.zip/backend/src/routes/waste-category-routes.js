const express = require("express");
const { pool } = require("../../config/database");
const { sendProblem } = require("../utils/problem-details");
const { negotiateResponse, toXml } = require("../utils/content-negotiation");

const router = express.Router();

router.get("/", async (req, res, next) => {
  try {
    const [rows] = await pool.execute(
      "SELECT id, name FROM waste_categories ORDER BY name"
    );
    const categories = rows.map((row) => ({ id: Number(row.id), name: row.name }));
    const format = negotiateResponse(req);
    if (!format) {
      return sendProblem(res, 406, "not-acceptable", "Not Acceptable",
        "Use Accept: application/json or Accept: application/xml.");
    }
    if (format === "xml") return res.type("application/xml").send(toXml(categories));
    return res.json(categories);
  } catch (error) {
    next(error);
  }
});

module.exports = router;
