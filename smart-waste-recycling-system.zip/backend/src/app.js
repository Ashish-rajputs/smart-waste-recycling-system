const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const apiRoutes = require("./routes");
const { notFoundHandler, errorHandler } = require("./middleware/error-handler");

const app = express();

app.disable("x-powered-by");
app.use(helmet());
app.use(cors({
  origin: process.env.CORS_ORIGIN
    ? process.env.CORS_ORIGIN.split(",").map((origin) => origin.trim())
    : true,
  methods: ["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Accept", "Authorization", "Idempotency-Key", "If-Match", "If-None-Match"],
  exposedHeaders: ["Location", "ETag", "Retry-After", "X-RateLimit-Limit", "X-RateLimit-Remaining"]
}));
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Cache-Control", "no-store");
  next();
});

app.use("/api", rateLimit({
  windowMs: Number(process.env.RATE_LIMIT_WINDOW_MS || 900000),
  limit: Number(process.env.RATE_LIMIT_MAX || 100),
  standardHeaders: true,
  legacyHeaders: true,
  handler: (req, res) => {
    res.setHeader("Retry-After", "900");
    res.status(429).type("application/problem+json").json({
      type: "https://smart-waste.example/problems/rate-limited",
      title: "Too Many Requests",
      status: 429,
      detail: "The request limit has been exceeded. Please try again later."
    });
  }
}));

app.get("/", (req, res) => {
  res.json({
    name: "Smart Waste Recycling Portal",
    status: "running",
    version: "1.0.0",
    documentation: "/api-docs/openapi.yaml"
  });
});

app.get("/health", (req, res) => res.status(200).json({ status: "ok" }));

app.get("/api-docs/openapi.yaml", (req, res) => {
  res.sendFile(require("path").join(__dirname, "..", "docs", "openapi.yaml"));
});

app.use("/api", apiRoutes);
app.use(notFoundHandler);
app.use(errorHandler);

module.exports = app;
