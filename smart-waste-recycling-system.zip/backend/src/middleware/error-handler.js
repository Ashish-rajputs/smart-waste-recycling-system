const { sendProblem } = require("../utils/problem-details");

function notFoundHandler(req, res) {
  return sendProblem(res, 404, "route-not-found", "Route not found",
    `No route exists for ${req.method} ${req.originalUrl}.`);
}

function errorHandler(error, req, res, next) {
  if (res.headersSent) return next(error);

  if (error && error.type === "entity.parse.failed") {
    return sendProblem(res, 400, "invalid-json", "Invalid JSON",
      "Check the request body syntax and set Content-Type: application/json.");
  }
  if (error && error.type === "entity.too.large") {
    return sendProblem(res, 413, "payload-too-large", "Payload too large",
      "The request body must be smaller than 100 KB.");
  }

  console.error(error);
  return sendProblem(res, 500, "internal-error", "Internal Server Error",
    "The server could not complete this request.");
}

module.exports = { notFoundHandler, errorHandler };
