# Smart Waste Recycling Portal

A backend API for a Smart Waste Recycling Portal. It manages recyclable material categories and pickup requests using Node.js, Express, and MySQL. This repository also contains academic documentation for Assignments 3–6, including a proposed SOAP partner contract, REST/OpenAPI design, HTTP semantics, validation, and error handling.

## Features
- Waste category listing.
- Create, list, retrieve, update, and delete pickup requests.
- Optional filtering by user ID and pickup status.
- Field validation and Problem Details error responses.
- JSON/XML response negotiation.
- Idempotency-key replay for duplicate create requests within the current process.
- ETag and conditional request support.
- Pickup lifecycle transitions.
- CORS, security headers, and rate limiting.
- OpenAPI 3.0 specification.
- SOAP WSDL and sample XML messages for an illustrative partner integration.

## Technology stack
- Node.js 20+
- Express
- MySQL 8+
- mysql2
- OpenAPI 3.0.3
- SOAP 1.1 examples for integration-design coursework

## Project structure

```text
smart-waste-recycling-portal/
├── config/
│   └── database.js
├── database/
│   └── schema.sql
├── docs/
│   ├── assignments/
│   ├── operations/
│   ├── soap-integration/
│   ├── api-reference.md
│   ├── architecture.md
│   ├── database-design.md
│   └── openapi.yaml
├── src/
│   ├── middleware/
│   ├── routes/
│   ├── utils/
│   └── app.js
├── test/
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── server.js
```

## Prerequisites
Install Node.js 20 or later and MySQL 8 or later.

## Installation

```bash
npm install
```

Create `.env` from the example:

```bash
cp .env.example .env
```

On Windows PowerShell:

```powershell
Copy-Item .env.example .env
```

Set your local MySQL username and password in `.env`. Do not commit `.env` or real credentials.

## Database setup

Run the schema in MySQL Workbench or from a terminal:

```bash
mysql -u root -p < database/schema.sql
```

Use a dedicated database account with access only to this database when possible.

## Start the API

```bash
npm start
```

Development mode:

```bash
npm run dev
```

Visit `http://localhost:3000/` or `http://localhost:3000/health`.

## Tests

```bash
npm test
npm run check
```

The included unit tests cover validation and helper logic. They do not prove that the API works against your local MySQL instance. Use the examples in `docs/operations/http-examples.txt` to test the running service and capture your own terminal output for academic evidence.

## API endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/` | API information |
| GET | `/health` | Health check |
| GET | `/api/waste-categories` | List categories |
| POST | `/api/pickups` | Create a pickup request |
| GET | `/api/pickups` | List/filter pickups |
| GET | `/api/pickups/:id` | Retrieve a pickup |
| PATCH | `/api/pickups/:id` | Update status, address, or quantity |
| DELETE | `/api/pickups/:id` | Delete a Pending or Cancelled pickup |

Full API contract: `docs/openapi.yaml`.

## Example create request

```json
{
  "wasteCategoryId": 1,
  "quantityKg": 4.5,
  "address": "Hostel Block A, Demo Campus"
}
```

## Pickup status transitions

- Pending -> Scheduled or Cancelled
- Scheduled -> Collected or Cancelled
- Collected -> Recycled
- Recycled and Cancelled are terminal states

## Academic assignment documentation
- Assignment 3: `docs/assignments/assignment-3-soap-integration.md`
- Assignment 4: `docs/assignments/assignment-4-rest-api.md`
- Assignment 5: `docs/assignments/assignment-5-http-methods-and-headers.md`
- Assignment 6: `docs/assignments/assignment-6-validation-and-errors.md`

## Limitations and future work
- The SOAP endpoint is illustrative and is not connected to a real recycling partner.
- Idempotency data is in memory and resets when the process restarts.
- Authentication, authorization, user ownership checks, and a users table are not implemented.
- Add integration tests with a test database before treating the API as production-ready.
- Add frontend, collector workflows, admin reporting, and real recycling-partner integration as future modules.

## Security notes
Never commit passwords, tokens, or personal addresses. Use environment variables for local configuration. If a credential was previously committed to a repository, rotate it; deleting it from the latest commit alone may not remove it from Git history.
