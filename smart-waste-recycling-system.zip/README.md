# Smart Waste Recycling System

Full-stack project: **Express + MySQL REST API** (`backend/`) and a **React + Vite** web app (`frontend/`).

## 1. Backend (http://localhost:3000)
```bash
cd backend
npm install
cp .env.example .env        # set DB_USER / DB_PASSWORD
mysql -u root -p < database/schema.sql
npm run dev
```

## 2. Frontend (http://localhost:5173)
```bash
cd frontend
npm install
cp .env.example .env        # VITE_API_URL=http://localhost:3000
npm run dev
```

The backend's `CORS_ORIGIN` already allows `http://localhost:5173`.

## Frontend features
- Dashboard stats (requests, open requests, total kg, recycled kg)
- Create pickup request (category dropdown, validation errors from the API shown per field, Idempotency-Key sent automatically)
- List and filter pickups by status
- Status workflow buttons that follow the backend rules (Pending → Scheduled → Collected → Recycled, or Cancelled)
- Edit address/quantity and delete Pending/Cancelled pickups (uses ETag / If-Match)
